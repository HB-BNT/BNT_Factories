/* CIN source file */

#include "extcode.h"

MgErr CINRun(LStrHandle Input, LStrHandle arg1, int32 *CompressionLevel, 
	int32 *arg2);

MgErr CINRun(LStrHandle Input, LStrHandle arg1, int32 *CompressionLevel, 
	int32 *arg2)
	{

	/* Insert code here */

	return noErr;
	}